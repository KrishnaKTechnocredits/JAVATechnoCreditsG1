package technoCredits.fileHandling;

import java.io.IOException;

public class Ex3 {

	void m3() throws IOException, InterruptedException{
		System.out.println("Ex3 m3");
	}
}
