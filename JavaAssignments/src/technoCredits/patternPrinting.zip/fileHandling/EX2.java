package technoCredits.fileHandling;

import java.io.IOException;

public class EX2 {

	void m2() throws Exception, IOException, InterruptedException{
		System.out.println("Ex2 m2");
		Ex3 ex3 = new Ex3();
		ex3.m3();
	}
}
