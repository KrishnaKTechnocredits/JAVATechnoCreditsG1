package technoCredits.fileHandling;

public class D {

	void m4(){
		System.out.println("D m4 start");
		int x = 10/0;
		System.out.println("D m4 END");
	}
}
