package technoCredits.fileHandling;

public class C {
	
	void m3(){
		System.out.println("C m3 start");
		int s = 5/0;
		System.out.println("C m3 END");
	}

}
